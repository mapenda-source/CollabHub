package com.mapenda.collabhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollabhubApplicationTests {

	@Test
	void contextLoads() {
	}

}

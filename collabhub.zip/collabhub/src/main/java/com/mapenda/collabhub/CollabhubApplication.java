package com.mapenda.collabhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollabhubApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollabhubApplication.class, args);
	}

}
